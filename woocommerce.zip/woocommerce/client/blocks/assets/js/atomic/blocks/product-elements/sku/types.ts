export interface Attributes {
	productId: number;
	showProductSelector: boolean;
	isDescendantOfAllProducts: boolean;
	prefix: string;
	suffix: string;
}
