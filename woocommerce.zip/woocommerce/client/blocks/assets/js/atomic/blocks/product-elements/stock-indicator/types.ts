export interface BlockAttributes {
	isDescendantOfAllProducts: boolean;
}
