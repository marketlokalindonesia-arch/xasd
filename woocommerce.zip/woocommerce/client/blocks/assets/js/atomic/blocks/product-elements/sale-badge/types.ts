export interface BlockAttributes {
	productId: number;
	isDescendentOfQueryLoop?: boolean | undefined;
	isDescendentOfSingleProductTemplate?: boolean;
	isDescendentOfSingleProductBlock?: boolean;
}
