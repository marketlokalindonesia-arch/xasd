# WooCommerce Blocks - General Purpose Components

These are shared components used in WooCommerce blocks, and may be used in the store front end (shopper experience) as well as the editor or admin dashboard.

See [_Components & Storybook_](../../../../docs/contributors/storybook-and-components.md) doc for more information.
