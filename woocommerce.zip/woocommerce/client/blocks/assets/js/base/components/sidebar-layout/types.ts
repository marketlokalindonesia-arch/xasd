export type ForwardRefProps = {
	children: JSX.Element | JSX.Element[];
	className?: string;
};
