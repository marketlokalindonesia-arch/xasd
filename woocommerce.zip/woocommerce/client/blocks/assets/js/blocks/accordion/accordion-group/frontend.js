/**
 * External dependencies
 */
import { store, getContext } from '@wordpress/interactivity';

const { state } = store( 'woocommerce/accordion', {
	state: {
		get isOpen() {
			const { isOpen, id } = getContext();
			return isOpen.includes( id );
		},
	},
	actions: {
		toggle: () => {
			const context = getContext();
			const { id, autoclose } = context;

			if ( autoclose ) {
				context.isOpen = state.isOpen ? [] : [ id ];
			} else if ( state.isOpen ) {
				context.isOpen = context.isOpen.filter(
					( item ) => item !== id
				);
			} else {
				context.isOpen.push( id );
			}
		},
	},
	callbacks: {
		initIsOpen: () => {
			const context = getContext();
			const { id, openByDefault } = context;
			if ( openByDefault ) {
				context.isOpen.push( id );
			}
		},
	},
} );
